[![back to root readme](../../back-button.png)](./../../readme.md)
# Cli Module 

## Api 
- [x] cli:start

|   Command	|  Data 	|  Action 	|  Information 	|
|---	|---	|---	|---	|	
| cli:start  	|  	|   start()	| will run cli programm   	|  	
| warehouse:store-item=success  	|  	|   showResponse()	| displays new Item stored   	|  	
| warehouse:store-item=full_storage  	|  	|   showResponse()	| displays Warehouse full   	|  	
| warehouse:store-item=unkownHazard  	|  	|   showResponse()	| displays Hazard unknown   	|  	
