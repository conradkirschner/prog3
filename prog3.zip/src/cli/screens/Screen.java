package cli.screens;

/**
 * Screens should be able to load without parameter!
 */
public interface Screen {
    void getContent();
    void getUsage();
}
