package gui.model;

public class User {
}
