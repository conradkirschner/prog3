package gui.model;

public class Warehouse {
    private String name;

    public String getName() {
        return name;
    }

    public Warehouse(String name) {
        this.name = name;
    }
}
