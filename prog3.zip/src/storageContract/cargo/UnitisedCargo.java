package storageContract.cargo;

public interface UnitisedCargo extends Cargo {
    boolean isFragile();
}
