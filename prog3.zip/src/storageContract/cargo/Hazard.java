package storageContract.cargo;

public enum Hazard {
    explosive,flammable,toxic,radioactive
}
