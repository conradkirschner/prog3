package storageContract.cargo;

public interface LiquidBulkCargo extends Cargo {
    boolean isPressurized();
}
