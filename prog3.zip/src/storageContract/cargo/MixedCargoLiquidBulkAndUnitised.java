package storageContract.cargo;

public interface MixedCargoLiquidBulkAndUnitised extends LiquidBulkCargo, UnitisedCargo {}
