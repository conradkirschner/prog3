package warehouse.events;

import app.events.Event;

public class FailedToInsert extends Error implements Event {
}
