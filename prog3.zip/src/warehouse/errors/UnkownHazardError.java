package warehouse.errors;


public class UnkownHazardError extends Error {
}
