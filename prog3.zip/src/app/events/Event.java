package app.events;

public interface Event {
}
