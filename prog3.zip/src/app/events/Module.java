package app.events;

import app.App;

public interface Module {
    public String getName();
}
