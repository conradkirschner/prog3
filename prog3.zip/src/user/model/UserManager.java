package user.model;

import app.App;
import app.events.Event;
import user.entity.Customer;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Set;

public class UserManager {
    private ArrayList<Customer> user;

    public UserManager() {
        this.user = new ArrayList<Customer>();
    }

    public Customer newCustomer(String name) {
        Customer customer = new Customer(name);
        this.user.add(customer);
        return customer;
    }

    public Customer updateCustomer(int id, String name) {
        Customer customer = this.user.get(id);
        customer.setName(name);
        return customer;
    }

    public Customer getCustomer(String name) {
        for(Customer customer: user) {
            if (customer.getName().equals(name)) {
                return customer;
            }
        }
        return null;
    }

    public Customer getCustomer(int id) {
        return this.user.get(id);
    }
    public ArrayList<Customer> getCustomers() {
        return this.user;
    }

    public Event deleteCustomer(String name) {
        int index = -1;
        for(int i =0; i < this.user.size(); i++) {
            if(this.user.get(i).getName().equals(name)) {
                index = i;
            }
        }
        if (index != -1) {
            this.user.remove(index);
        }
        return null;
    }


}
